export async function onRequestGet(context) {
  const { searchParams } = new URL(context.request.url);
  const code = searchParams.get("code");

  return new Response(`OAuth2 code: ${code}`, {
    headers: { "Content-Type": "text/html" }
  });
}
